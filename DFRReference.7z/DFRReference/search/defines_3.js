var searchData=
[
  ['error_5frpt_5fpulse_5fwidth',['ERROR_RPT_PULSE_WIDTH',['../DFRMain_8ino.html#a574d83c43157939e3d608bde6f6ca3b9',1,'DFRMain.ino']]],
  ['error_5frpt_5fspacing',['ERROR_RPT_SPACING',['../DFRMain_8ino.html#ad42a9512792ac50ebd25b45585fdb2ba',1,'DFRMain.ino']]]
];
