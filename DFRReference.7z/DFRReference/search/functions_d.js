var searchData=
[
  ['transittoidlemode',['transitToIdleMode',['../DFRMain_8ino.html#a6e432e877cfcac527c10784205ca7dec',1,'DFRMain.ino']]],
  ['transittoplaybackmode',['transitToPlaybackMode',['../DFRMain_8ino.html#a07a4487c799299fe1f28207a315dc2ba',1,'DFRMain.ino']]],
  ['transittorecordmode',['transitToRecordMode',['../DFRMain_8ino.html#a1c694cf36d4ee0dbc0ff874a742e0b6d',1,'DFRMain.ino']]]
];
