var searchData=
[
  ['channelname',['channelName',['../classChannelSelector.html#a7b2851382f7681bc30a9446378f7b778',1,'ChannelSelector']]],
  ['channelselect',['ChannelSelect',['../DFRMain_8ino.html#aededadef504eb3bc09bd5fb2f8b59a83',1,'ChannelSelect():&#160;DFRMain.ino'],['../ChannelSelectorTest_8ino.html#aededadef504eb3bc09bd5fb2f8b59a83',1,'ChannelSelect():&#160;ChannelSelectorTest.ino']]],
  ['channelselectpin',['ChannelSelectPin',['../DFRMain_8ino.html#ac42845e5178b92bf69a09e19961fb181',1,'ChannelSelectPin():&#160;DFRMain.ino'],['../ChannelSelectorTest_8ino.html#ac42845e5178b92bf69a09e19961fb181',1,'ChannelSelectPin():&#160;ChannelSelectorTest.ino']]],
  ['currentchannel',['currentChannel',['../classChannelSelector.html#a1aeaeb0c3b066491757f8300f552c426',1,'ChannelSelector']]],
  ['currentfilename',['currentFileName',['../classPulseTrainRecorder.html#a11952555dcbd726c1c1ca373c7d1a84f',1,'PulseTrainRecorder']]],
  ['currentmode',['currentMode',['../DFRMain_8ino.html#a363383d69f3dd6aed75c2fbd8d7b8368',1,'DFRMain.ino']]],
  ['currentpinmode',['currentPinMode',['../classDigitalInputPin.html#aa27f55a7b318d79434f1b05c968aae34',1,'DigitalInputPin']]],
  ['currentpulseendtime',['currentPulseEndTime',['../classPulseTrainRecorder.html#a5730abb1147571b3209d0448fef8733a',1,'PulseTrainRecorder']]],
  ['currentpulsestarttime',['currentPulseStartTime',['../classPulseTrainRecorder.html#a90c2edc7f42bbf8629f48dee3c603775',1,'PulseTrainRecorder']]]
];
