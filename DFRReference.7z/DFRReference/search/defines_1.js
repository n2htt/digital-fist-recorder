var searchData=
[
  ['channel_5ffilename_5fmax',['CHANNEL_FILENAME_MAX',['../PulseTrainRecorder_8h.html#a666aa0025f7467bd147861681bdf42bc',1,'PulseTrainRecorder.h']]],
  ['channel_5fselector_5fpin',['CHANNEL_SELECTOR_PIN',['../dfrconstants_8h.html#a3e0c49a47f0bc65f88d2ef0bfe4577e1',1,'CHANNEL_SELECTOR_PIN():&#160;dfrconstants.h'],['../ChannelSelectorTest_8ino.html#a3e0c49a47f0bc65f88d2ef0bfe4577e1',1,'CHANNEL_SELECTOR_PIN():&#160;ChannelSelectorTest.ino']]],
  ['cselct_5fdisplay_5fchannel_5flead_5fmils',['CSELCT_DISPLAY_CHANNEL_LEAD_MILS',['../ChannelSelector_8h.html#a8ff3676c79bd1c2c7980a10a692a0f34',1,'ChannelSelector.h']]],
  ['cselct_5fdisplay_5fchannel_5fpulse_5fwidth_5fmils',['CSELCT_DISPLAY_CHANNEL_PULSE_WIDTH_MILS',['../ChannelSelector_8h.html#aa7892b21741d7a6683aa6849f7796934',1,'ChannelSelector.h']]],
  ['cselct_5fdisplay_5fchannel_5fspacing_5fwidth_5fmils',['CSELCT_DISPLAY_CHANNEL_SPACING_WIDTH_MILS',['../ChannelSelector_8h.html#a2e57719fec19e7aaf76002b5c8adf65a',1,'ChannelSelector.h']]],
  ['cselct_5fpause_5fbefore_5freport_5fmils',['CSELCT_PAUSE_BEFORE_REPORT_MILS',['../ChannelSelector_8h.html#ab60bfa0a5ddc489f3e1ec777f8dafb4f',1,'ChannelSelector.h']]]
];
