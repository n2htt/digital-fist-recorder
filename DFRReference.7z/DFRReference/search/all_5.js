var searchData=
[
  ['getchannelname',['getChannelName',['../classChannelSelector.html#adbb8753edea223128b3205563626cbf5',1,'ChannelSelector']]],
  ['getcurrentchannel',['getCurrentChannel',['../classChannelSelector.html#a1daa29f6fab5e5d2ce6d401744ed0135',1,'ChannelSelector']]],
  ['getcurrentchannelname',['getCurrentChannelName',['../classChannelSelector.html#a2d6f83a6cbaaeae0e9bcebd1cef6b88d',1,'ChannelSelector']]],
  ['getcurrentpinmode',['getCurrentPinMode',['../classDigitalInputPin.html#a6eaf4b8bd7fe6660951a265572ca740c',1,'DigitalInputPin::getCurrentPinMode()'],['../classModeSelector.html#a51a861c063b00121ecd9e6fa219fa702',1,'ModeSelector::getCurrentPinMode()']]],
  ['getdescription',['getDescription',['../structDigitalPulse.html#ae9022f4b28be1db577579aa3fa9769a1',1,'DigitalPulse']]],
  ['getlastpulse',['getLastPulse',['../classDigitalInputPin.html#abb2215ad9472084665aa68d6ac677ed7',1,'DigitalInputPin']]],
  ['getlogicalstate',['getLogicalState',['../classDigitalPin.html#ab1a1b176937c3bdf17551302e6951df6',1,'DigitalPin']]],
  ['getplaybacklogicalstate',['getPlaybackLogicalState',['../classPulseTrainRecorder.html#ae43d3db780fef37641352509da83aa9b',1,'PulseTrainRecorder']]],
  ['getstate',['getState',['../classDigitalPin.html#a85a62001d4e9fea9b2fb5fa5b053d64b',1,'DigitalPin']]]
];
