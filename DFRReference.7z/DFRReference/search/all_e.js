var searchData=
[
  ['readinputpulsemode',['readInputPulseMode',['../classChannelSelector.html#a60e380b5e348d160c8bb86d1ae5cd811',1,'ChannelSelector::readInputPulseMode()'],['../classDigitalInputPin.html#a59e028af411f77800a53773fbcc47357',1,'DigitalInputPin::readInputPulseMode()'],['../classModeSelector.html#af1837c0ff2fc97d98110b9592c9cc008',1,'ModeSelector::readInputPulseMode()']]],
  ['readnextpulse',['readNextPulse',['../classPulseTrainRecorder.html#aca576cc6566aab54b179d40d6ec9ac61',1,'PulseTrainRecorder']]],
  ['recording_5fchannels',['RECORDING_CHANNELS',['../ChannelSelector_8h.html#a2b3cf6adb38f5be630e88783772f4617',1,'ChannelSelector.h']]],
  ['recordpulse',['recordPulse',['../classPulseTrainRecorder.html#a17d9fe89f84e9d0dcac91d4fc4dda21d',1,'PulseTrainRecorder']]],
  ['reportchannel',['reportChannel',['../classChannelSelector.html#a4beebc573e038b91f5c795f3b3edf714',1,'ChannelSelector']]],
  ['reset',['reset',['../structDigitalPulse.html#a7c1bf23a81e4897345e82607b118d26e',1,'DigitalPulse']]],
  ['resume',['resume',['../classDigitalPin.html#ad4b12f73ef17614f835aab7633e5538b',1,'DigitalPin']]]
];
