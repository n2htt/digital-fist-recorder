var searchData=
[
  ['recording_5fchannels',['RECORDING_CHANNELS',['../ChannelSelector_8h.html#a2b3cf6adb38f5be630e88783772f4617',1,'ChannelSelector.h']]]
];
