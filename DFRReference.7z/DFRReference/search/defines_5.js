var searchData=
[
  ['inner_5floop_5fcount',['INNER_LOOP_COUNT',['../ChannelSelector_8cpp.html#a45ba4dc708d4b17a9384869db5eab4ca',1,'ChannelSelector.cpp']]],
  ['inner_5floop_5fdelay_5fmils',['INNER_LOOP_DELAY_MILS',['../ChannelSelector_8cpp.html#a985b94845ede34657b7f078b24497e36',1,'ChannelSelector.cpp']]]
];
