var searchData=
[
  ['auto_5freset_5fct',['AUTO_RESET_CT',['../DFRMain_8ino.html#af9e050960fb6c51c8c55557e40b7e1b3',1,'DFRMain.ino']]],
  ['auto_5freset_5fmils',['AUTO_RESET_MILS',['../ModeSelectorTest_8ino.html#a80d33a6b6a0259d94a5b73856e7dc847',1,'ModeSelectorTest.ino']]]
];
