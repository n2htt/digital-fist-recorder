var searchData=
[
  ['not_5fused_5fpin',['NOT_USED_PIN',['../dfrconstants_8h.html#a0dc29fffe260aa3466a1dbce1ea88326',1,'NOT_USED_PIN():&#160;dfrconstants.h'],['../dfrconstants_8h.html#a0dc29fffe260aa3466a1dbce1ea88326',1,'NOT_USED_PIN():&#160;dfrconstants.h']]]
];
