var searchData=
[
  ['welcome_5fpulse_5fwidth',['WELCOME_PULSE_WIDTH',['../DFRMain_8ino.html#a1ef79bf9528dbbfa17071a8b29b033aa',1,'DFRMain.ino']]],
  ['welcome_5fspacing',['WELCOME_SPACING',['../DFRMain_8ino.html#acbc5b0e11f83afa865b85618a6f5448f',1,'DFRMain.ino']]]
];
